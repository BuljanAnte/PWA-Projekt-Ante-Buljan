<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Le Monde</title>
    <meta name="description" content="Number 1 website for news.">
    <meta name="keywords" content="Politics, sport">
    <meta name="author" content="Ante Buljan">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <header>
        <img src="slike/logo.png" class="logo" alt="logo">
        <div class="horizontalLine"></div>
        <nav>
            <a href="index.php" class="navLink"><div class="navButton">Home</div></a>
            <a href="politique.php" class="navLink"><div class="navButton">Politique</div></a>
            <a href="sport.php" class="navLink"><div class="navButton">Sport</div></a>
            <a href="unos.html" class="navLink"><div class="navButton">Unos</div></a>
            <a href="#administracija" class="navLink"><div class="navButton">Administracija</div></a>
        </nav>
    </header>
    


    <section class="content">
       
    <form name="register" action="" method="post">
                <label for="korisnicko_ime">Korisnicko ime:</label>
                <input type="text" name="korisnicko_ime" id="korisnicko_ime"><br>
                <label for="ime">Ime:</label>
                <input type="text" name="ime" id="ime"><br>
                <label for="prezime">Prezime:</label>
                <input type="text" name="prezime" id="prezime"><br>
                <label for="lozinka">Lozinka:</label>
                <input type="password" name="lozinka" id="lozinka"><br>
                <label for="lozinka2">Ponovi lozinku:</label>
                <input type="password" name="lozinka2" id="lozinka2"><br>
                <input type="submit" name="submit" value="Pošalji">
            </form>
            <a href="login.php">Imate korisnicki racun?</a>
  
    
    </section>
    
    


    <footer>
        <hr class="footerLine">
        <p><b>SUIVEZ LE MONDE</b></p>
        <p>&copy; 2022 Ante Buljan. All Rights Reserved.</p>
    </footer>
</body>
</html>