<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Le Monde</title>
    <meta name="description" content="Number 1 website for news.">
    <meta name="keywords" content="Politics, sport">
    <meta name="author" content="Ante Buljan">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <header>
        <img src="slike/logo.png" class="logo" alt="logo">
        <div class="horizontalLine"></div>
        <nav>
            <a href="index.php" class="navLink"><div class="navButton">Home</div></a>
            <a href="#politique" class="navLink"><div class="navButton">Politique</div></a>
            <a href="sport.php" class="navLink"><div class="navButton">Sport</div></a>
            <a href="unos.html" class="navLink"><div class="navButton">Unos</div></a>
            <a href="administrator.php" class="navLink"><div class="navButton">Administracija</div></a>
        </nav>
    </header>
    


    <section class="content">
        <section class="newsBlock">
            <h1>Politique</h1>
            <div class="articleBlock">
                <article class="homeArticle">
                    <?php 
                        include 'connect.php';
                        define('UPLPATH', 'slike/');
                        $query = "SELECT * FROM tablica WHERE arhiva=0 AND kategorija='politique' LIMIT 4";
                        $result = mysqli_query($dbc, $query);
                        while($row = mysqli_fetch_array($result)) {
                            if($row['kategorija'] == 'politique'){
                                echo '<img src="' . UPLPATH . $row['slika'] . '" class="articleImage" alt="slika"'; 
                                echo '<a href="clanak.php" class="newsLink">' . '<h3>' . $row['naslov'] . '</h3>' . '</a>';
                            }
                        }
                    ?>
                </article>
            </div>
        </section>
    </section>
    


    <footer>
        <hr class="footerLine">
        <p><b>SUIVEZ LE MONDE</b></p>
        <p>&copy; 2022 Ante Buljan. All Rights Reserved.</p>
    </footer>
</body>
</html>