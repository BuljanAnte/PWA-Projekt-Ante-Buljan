<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Le Monde</title>
    <meta name="description" content="Number 1 website for news.">
    <meta name="keywords" content="Politics, sport">
    <meta name="author" content="Ante Buljan">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <header>
        <img src="slike/logo.png" class="logo" alt="logo">
        <div class="horizontalLine"></div>
        <nav>
            <a href="index.php" class="navLink"><div class="navButton">Home</div></a>
            <a href="politique.php" class="navLink"><div class="navButton">Politique</div></a>
            <a href="sport.php" class="navLink"><div class="navButton">Sport</div></a>
            <a href="unos.html" class="navLink"><div class="navButton">Unos</div></a>
            <a href="administracija.php" class="navLink"><div class="navButton">Administracija</div></a>
        </nav>
    </header>
    


    <section class="content">
        <h3 class="newsCategory">
        <?php
            if (isset($_POST['category'])){
			    $category=$_POST['category'];
			    echo $category;
		    }
        ?>
        </h3>
        
        <h1 class="newsTitle">
            <?php
                if (isset($_POST['title'])){
			        $title=$_POST['title'];
			        echo $title;
		        }
            ?>
        </h1>

        <p class="newsSynopsis">
            <?php 
                if (isset($_POST['synopsis'])){
                    $synopsis=$_POST['synopsis'];
                    echo $synopsis;
                }
            ?>
        </p>
        
        <?php
        if (isset($_FILES['pphoto']['name'])){
			$pphoto=$_FILES['pphoto']['name'];
			if(!empty($pphoto)){
                echo "<img src='slike/$pphoto' class='newsImage' alt='slika'";
            }
		}
        ?>

        <p class="newsParagraph">
        <?php
            if (isset($_POST['content'])){
			    $content=$_POST['content'];
			    echo $content;
		}
        ?>
        </p>
    </section>
    

    <?php
        include 'connect.php';

        $target_dir = 'slike/'.$pphoto;
        move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);

        $datum = date("d.m.Y.");

        if (isset($_POST['archive'])){
			$archive= 1;
		}else{
            $archive= 0;
        }

        $query = "INSERT INTO tablica (datum, naslov, sazetak, tekst, slika, kategorija, arhiva) VALUES ('$datum', '$title', '$synopsis', '$content', '$pphoto', '$category', '$archive')";
        $result = mysqli_query($dbc, $query) or die('Error querying databese.');
        mysqli_close($dbc);
    ?>
    
    <footer>
        <hr class="footerLine">
        <p><b>SUIVEZ LE MONDE</b></p>
        <p>&copy; 2022 Ante Buljan. All Rights Reserved.</p>
    </footer>
</body>
</html>

