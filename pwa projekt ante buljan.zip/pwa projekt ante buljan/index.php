<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Le Monde</title>
    <meta name="description" content="Number 1 website for news.">
    <meta name="keywords" content="Politics, sport">
    <meta name="author" content="Ante Buljan">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <header>
        <img src="slike/logo.png" class="logo" alt="logo">
        <div class="horizontalLine"></div>
        <nav>
            <a href="#home" class="navLink"><div class="navButton">Home</div></a>
            <a href="politique.php" class="navLink"><div class="navButton">Politique</div></a>
            <a href="sport.php" class="navLink"><div class="navButton">Sport</div></a>
            <a href="unos.html" class="navLink"><div class="navButton">Unos</div></a>
            <a href="administrator.php" class="navLink"><div class="navButton">Administracija</div></a>
        </nav>
    </header>
    


    <section class="content">
        <section class="newsBlock">
            <h1>Politique</h1>
            <div class="articleBlock">
                <article class="homeArticle">
                    <img src="slike/slika1_crop.jpg" class="articleImage" alt="slika1 cropped">
                    <img src="slike/slika1.jpg" class="articleImage" alt="slika1">
                    <a href="#clanak" class="newsLink"><h3>Pour la Cour de Luxembourg, les patrons doivent mesurer « le temps de travail journalier »</h3></a>
                </article>
                <article class="homeArticle">
                    <img src="slike/slika1_crop.jpg" class="articleImage" alt="slika1 cropped">
                    <img src="slike/slika1.jpg" class="articleImage" alt="slika1">
                    <a href="#clanak" class="newsLink"><h3>Pour la Cour de Luxembourg, les patrons doivent mesurer « le temps de travail journalier »</h3></a>
                </article>
                <article class="homeArticle">
                    <img src="slike/slika1_crop.jpg" class="articleImage" alt="slika1 cropped">
                    <img src="slike/slika1.jpg" class="articleImage" alt="slika1">
                    <a href="#clanak" class="newsLink"><h3>Pour la Cour de Luxembourg, les patrons doivent mesurer « le temps de travail journalier »</h3></a>
                </article>
            </div>
        </section>

        <section class="newsBlock">
            <h1>Sport</h1>
            <div class="articleBlock">
                <article class="homeArticle">
                    <img src="slike/slika3_crop.jpg" class="articleImage" alt="slika3 croppped">
                    <a href="clanak.php" class="newsLink"><h3>NBA : pourquoi la télévision turque ne diffuse pas les finales de conférence Ouest</h3></a>
                </article>
                <article class="homeArticle">
                    <img src="slike/slika2.jpg" class="articleImage" alt="slika2">
                    <a href="#clanak" class="newsLink"><h3>Dopage : la Slovénie au cœur de la tempête « Aderlass »</h3></a>
                </article>
                <article class="homeArticle">
                    <img src="slike/slika2.jpg" class="articleImage" alt="slika2">
                    <a href="#clanak" class="newsLink"><h3>Dopage : la Slovénie au cœur de la tempête « Aderlass »</h3></a>
                </article>

                <article class="homeArticle">
                    <?php
                        $dbc = mysqli_connect('localhost', 'root', '', 'baza_podataka') or die('Error connecting to MySQL server.'. mysqli_connect_error());
                        $query = "SELECT * FROM tablica WHERE arhiva=0 AND kategorija='sport' LIMIT 4";
                        $result = mysqli_query($dbc, $query);
                        $row = mysqli_fetch_array($result);
                        while($row = mysqli_fetch_array($result)) {
                            echo $row['datum'] . ' ' . $row['naslov'] . ' ' . $row['tekst'] . '<br />';
                           }
                    ?>
                </article>
            </div>
        </section>
    </section>
    
    


    <footer>
        <hr class="footerLine">
        <p><b>SUIVEZ LE MONDE</b></p>
        <p>&copy; 2022 Ante Buljan. All Rights Reserved.</p>
    </footer>
</body>
</html>

